---
url: "https://www.schluesseldienst-adam.de/tuer-fenstereinbau"
title: "Tür- & Fenstereinbau Hochheim | RC2/RC3 Einbruchschutz"
---

Sicherheitseinbau Hochheim

# Sicherheitstüren & Fenster – Einbau vom Fachmann

Ein sicheres Zuhause beginnt an der Schwelle. Einbruchhemmende Türen und Fenster bilden die erste Verteidigungslinie gegen ungebetene Gäste – und steigern zugleich den Wert Ihrer Immobilie.

Schlüsseldienst Adam in Hochheim bietet professionelle Beratung, präzises Aufmaß und fachgerechte Montage aus einer Hand. Rufen Sie [0176 23257435](tel:+4917623257435) an für eine unverbindliche Beratung.

![Google](https://www.schluesseldienst-adam.de/assets/google-CVaYQB6C.webp)

Google Bewertungen

5.0★★★★★

Basierend auf 177 Bewertungen

![ProvenExpert](https://www.schluesseldienst-adam.de/assets/provenexpert-TVEOcDbq.webp)

ProvenExpert.com

5.0★★★★★

Basierend auf 196 Bewertungen

ADAC Schlüsselnotdienst-Partner

### Geprüfter Einbruchschutz (RC2/RC3)

Zertifizierte Sicherheitstüren und -fenster, die nach polizeilicher Empfehlung auch professionellen Einbruchsversuchen standhalten.

### Individuelle Beratung & Aufmaß

Vor-Ort-Analyse Ihrer Schwachstellen, maßgeschneiderte Lösung und präzises Aufmaß für perfekte Passform.

### Fachgerechte Montage & Entsorgung

Professioneller Einbau nach aktuellen Normen, inklusive Demontage und Entsorgung alter Elemente.

99%

schadenfrei geöffnet

Ø 30 Min

Anfahrtszeit

5.0 ★

Google Bewertung

Festpreis

inkl. MwSt. & Anfahrt

So funktioniert's

## In 4 Schritten zu mehr Sicherheit

1

### Beratungsgespräch

Schildern Sie Ihre Wünsche und Anforderungen. Wir beraten Sie zu Materialien, Sicherheitsklassen und Optionen.

2

### Aufmaß vor Ort

Präzises Aufmaß an Ihrem Objekt. So stellen wir sicher, dass jedes Element passgenau gefertigt wird.

3

### Fachgerechte Montage

Professioneller Einbau durch erfahrene Monteure – sauber, termingerecht und nach aktuellen Normen.

4

### Abnahme & Einweisung

Gemeinsame Prüfung aller Funktionen. Sie erhalten eine Einweisung in Bedienung und Pflege.

[Jetzt beraten lassen: 0176 / 232 574 35](tel:+4917623257435)

Verfügbarkeit prüfen

## Sind wir in Ihrer Nähe?

Geben Sie Ihre Postleitzahl ein und erfahren Sie sofort, wie schnell wir bei Ihnen sein können.

Prüfen

Unsere Leistungen

## Sicherheitseinbau – unser Leistungsspektrum

### Einbruchhemmende Türen

Sicherheitstüren nach RC2 und RC3 Standard mit Mehrfachverriegelung – wirksamer Schutz vor Einbruchsversuchen.

### Sicherheitsfenster

Fenster mit Pilzkopfverriegelung, Sicherheitsglas und verstärkten Beschlägen – eine Barriere, die standhält.

### Nachrüstlösungen

Panzerriegel, Querriegelschlösser und abschließbare Griffe: Wir werten Ihre bestehenden Türen und Fenster auf.

### Komplettsanierung

Von der Planung bis zur Montage: Wir betreuen Ihr Projekt ganzheitlich – inklusive Demontage und Entsorgung.

## Warum Sicherheitstüren und -fenster Ihre beste Investition sind

Die Statistik ist eindeutig: Die meisten Einbrecher geben auf, wenn der Widerstand an Tür oder Fenster länger als drei Minuten dauert. Einbruchhemmende Elemente der Klassen RC2 und RC3 bieten genau diesen Schutz – und signalisieren bereits optisch, dass sich ein Versuch nicht lohnt.

Wir beraten Sie individuell zu Materialien, Verglasungen und Beschlägen, die optimal zu Ihrem Objekt passen. Von der Eigentumswohnung bis zum Einfamilienhaus, vom Erdgeschoss bis zum Dachfenster – jede Schwachstelle verdient eine maßgeschneiderte Lösung.

Auch die Nachrüstung bestehender Fenster und Türen kann den Schutz erheblich steigern. Pilzkopfverriegelungen, Panzerriegel und Sicherheitsbeschläge lassen sich häufig ohne bauliche Veränderungen integrieren – effektiv und wirtschaftlich.

![Sicherheitstechnik Tür- und Fenstereinbau](https://www.schluesseldienst-adam.de/assets/sicherheitstechnik-VU2fukcu.webp)

Zahlungsarten

Girocard

Mastercard

PayPal

VISA

VISA Electron

Apple Pay

Barzahlung

EC

Kundenstimmen

5.0

177 Bewertungen

G

Grazia Pisano

1\. März 2026

Sehr sehr freundlich! Am Anfang hatten wir etwas Unsicherheit, es war Sonntag Abend und wir befürchteten eine hohe Rechnung. Tarek Habid sagte uns schon am Telefon, dass es ein Festpreis trotz Uhrzeit gäbe. Vor Ort war er super freundlich und schnell. Es gab keinerlei Schäden und der Preis stimmte. Danke nochmal!

C

Cosmopolitan Girl Traveler

1\. März 2026

Bester Schlüsseldienst den es gibt! Sehr freundlich, hilfsbereit und kooperativ. 100% Weiterempfehlung! Herr Adam ist innerhalb kürzester Zeit da gewesen und auch die Haustür war schnell geöffnet. Herzlichen Dank für Alles!

O

Oliver Gossel

28\. Februar 2026

Bester Mann

Ihr Experte

## Ihr Spezialist für Schließtechnik in Hochheim: Tarek Habid

Sicherheit reicht weit über die Schwelle hinaus. Tarek Habid begleitet Sie als Fachmann für Sicherheitstechnik in Hochheim und dem Rhein-Main-Raum. Er entwirft Konzepte für mechanischen Einbruchschutz, moderne Schließanlagen und Tresorsysteme, die exakt zu Ihrem Eigentum passen.

Im Anschluss an eine Türöffnung begutachtet er auf Wunsch Ihren aktuellen Schutzstatus und schlägt Optimierungen vor. Dabei stehen Präzision und eine klare Planung im Vordergrund.

Auf diese Weise verknüpfen Sie sofortige Unterstützung mit dauerhafter Vorsorge. Die Umsetzung erfolgt fachkundig, ganzheitlich und in höchster Qualität.

### Fachgerechte Türöffnungen

Spezialisierte Ausbildung bei Uwe Sarfeld und langjährige Erfahrung. In 99 % der Fälle öffne ich Türen ohne Schäden an Schloss oder Türrahmen.

### Einbruchschutz-Konzepte

Ich analysiere Schwachstellen an Ihrer Immobilie und entwickle maßgeschneiderte Sicherheitslösungen. So schützen Sie Ihr Eigentum wirksam vor Einbrechern.

### Moderne Schließanlagen

Ich installiere Schließsysteme, die zu Ihrem Bedarf passen - mechanisch oder elektronisch. Sie behalten die Kontrolle über jeden Zugang.

### Tresor-Installation

Ich berate Sie bei der Auswahl des richtigen Tresors und installiere ihn fachgerecht. Ihre Wertsache erhalten den Schutz, den sie verdienen.

### Zylinder-Austausch

Ich modernisiere veraltete Schließzylinder und bringe Ihre Sicherheit auf den neuesten Stand. Sie profitieren von geprüfter Qualität.

### 24/7-Notdienst

Ich bin rund um die Uhr für Sie erreichbar - im gesamten Rhein-Main-Gebiet. Sie erhalten schnelle, professionelle Hilfe, wenn Sie sie brauchen.

![Tarek Habid](https://www.schluesseldienst-adam.de/assets/tarek-habid-CPB2FS-q.webp)

Tarek Habid

Experte für Sicherheitstechnik

Einsatzgebiet

## Ihr Schlüsseldienst für Hochheim & Umgebung

Wir sind in unter 30 Minuten bei Ihnen – in Hochheim und allen umliegenden Orten.

[Hochheim](https://www.schluesseldienst-adam.de/hochheim) [Flörsheim](https://www.schluesseldienst-adam.de/floersheim) [Massenheim](https://www.schluesseldienst-adam.de/massenheim-hochheim) [Weilbach](https://www.schluesseldienst-adam.de/weilbach) [Hattersheim](https://www.schluesseldienst-adam.de/hattersheim) [Eddersheim](https://www.schluesseldienst-adam.de/eddersheim) [Hofheim](https://www.schluesseldienst-adam.de/hofheim) [Kriftel](https://www.schluesseldienst-adam.de/kriftel) [Kelkheim](https://www.schluesseldienst-adam.de/kelkheim) [Eschborn](https://www.schluesseldienst-adam.de/eschborn) [Kronberg](https://www.schluesseldienst-adam.de/kronberg) [Königstein](https://www.schluesseldienst-adam.de/koenigstein) [Bad Soden](https://www.schluesseldienst-adam.de/bad-soden) [Schwalbach](https://www.schluesseldienst-adam.de/schwalbach) [Raunheim](https://www.schluesseldienst-adam.de/raunheim) [Rüsselsheim](https://www.schluesseldienst-adam.de/ruesselsheim)

[Alle Einsatzgebiete ansehen →](https://www.schluesseldienst-adam.de/einsatzgebiete)

FAQ

## Häufige Fragen zu Sicherheitstüren & -fenstern

Schlüsseldienst Hochheim

### Was kostet ein Sicherheitsfenster?

Die Kosten variieren je nach Größe, Verglasung und Sicherheitsklasse. Wir erstellen Ihnen nach einer Vor-Ort-Beratung ein individuelles Angebot – transparent und ohne versteckte Posten.

### Wie lange dauert der Einbau einer Sicherheitstür?

Der Einbau einer einzelnen Sicherheitstür nimmt in der Regel 3 bis 5 Stunden in Anspruch. Bei umfangreicheren Projekten erstellen wir einen individuellen Zeitplan, der Ihren Alltag so wenig wie möglich beeinträchtigt.

### Welche Sicherheitsklassen (RC) bieten Sie an?

Wir verbauen Sicherheitstüren und -fenster der Widerstandsklassen RC1 bis RC3. Die passende Stufe wählen wir gemeinsam mit Ihnen anhand Ihrer individuellen Anforderungen und der örtlichen Gegebenheiten.

### Entfernen Sie auch die alten Fenster und Türen?

Selbstverständlich. Die fachgerechte Demontage und Entsorgung der alten Elemente ist in unserem Service enthalten. Sie erhalten alles aus einer Hand.

### Bieten Sie auch Nachrüstungen bestehender Fenster und Türen an?

Ja, wir rüsten bestehende Fenster und Türen mit Zusatzsicherungen nach: Pilzkopfverriegelungen, Panzerriegel, Sicherheitsbeschläge und abschließbare Fenstergriffe. Oft lässt sich der Schutz erheblich steigern, ohne komplett neue Elemente einbauen zu müssen.

### Beraten Sie auch zur KfW-Förderung für Einbruchschutz?

Ja, viele Maßnahmen zum Einbruchschutz sind förderfähig. Wir informieren Sie über die aktuellen Möglichkeiten und unterstützen Sie bei der Umsetzung förderfähiger Maßnahmen.

Jetzt Kontakt aufnehmen

## Schlüsseldienst Ihrer Stadt hilft – schnell und zuverlässig

Jeder Einsatz folgt einem Ziel: Sie sollen sich sofort wieder sicher fühlen. Unser Schlüsseldienst setzt auf Qualität, Struktur und Menschlichkeit. Wenn die Tür lediglich zugefallen ist, wenn der Schlüssel im Schloss abgebrochen oder das Schloss beschädigt ist, wir reagieren ruhig, klar und lösungsorientiert.

In Ihrer Stadt ist jederzeit jemand erreichbar. Sie rufen an, wir kommen. Ohne Umwege, ohne Unsicherheit. Das ist echte, effiziente Hilfe. Schnell und zuverlässig. Fair und transparent.

![Tarek Habid](https://www.schluesseldienst-adam.de/assets/tarek-habid-CPB2FS-q.webp)

24 Std. Schlüsselnotdienst

[0176 / 232 574 35](tel:+4917623257435)

![Google](https://www.schluesseldienst-adam.de/assets/google-CVaYQB6C.webp)

Google Bewertungen

5.0★★★★★

Basierend auf 177 Bewertungen

[In Maps öffnen ↗](https://www.google.com/maps/place/Weiherstr.+1,+65239+Hochheim+am+Main)

Weiherstraße 1

Weiherstraße 1, 65239 Hochheim am Main

[In Google Maps öffnen (wird in neuem Tab geöffnet)](https://maps.google.com/?cid=1260128461620753167&g_mp=CiVnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLkdldFBsYWNlEAMYASAF&hl=de&gl=DE&source=embed) Maps


[In Google Maps öffnen (wird in neuem Tab geöffnet)](https://maps.google.com/?cid=1260128461620753167&g_mp=CiVnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLkdldFBsYWNlEAMYASAF&hl=de&gl=DE&source=embed)

[Route berechnen (wird in neuem Tab geöffnet)](https://www.google.com/maps/dir//''/data=!4m7!4m6!1m1!4e2!1m2!1m1!1s0x47bd984bd74b7a67:0x117ce028ce43b30f!3e0?g_mp=CiVnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLkdldFBsYWNlEAMYASAF)

|     |     |
| --- | --- |
| `←` | Nach links |
| `→` | Nach rechts |
| `↑` | Nach oben |
| `↓` | Nach unten |
| `+` | Heranzoomen |
| `-` | Herauszoomen |
| `Pos1` | Um 75 % nach links |
| `Ende` | Um 75 % nach rechts |
| `Bild auf` | Um 75 % nach oben |
| `Bild ab` | Um 75 % nach unten |

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i16!2i34288!3i22223!4i256!2m3!1e0!2sm!3i798564590!2m3!1e2!2sspotlit!5i1!3m13!2sde!3sDE!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m16!299174093m15!14m14!1m9!1m2!1y5169455398793214567!2y1260128461620753167!2s%2Fg%2F11bw3x2gkh!4m2!1x500113093!2x83511942!8b1!15sgcid%3Acompound_building!2b0!3b0!6b0!8b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=17197)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i16!2i34287!3i22223!4i256!2m3!1e0!2sm!3i798564590!2m3!1e2!2sspotlit!5i1!3m13!2sde!3sDE!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m16!299174093m15!14m14!1m9!1m2!1y5169455398793214567!2y1260128461620753167!2s%2Fg%2F11bw3x2gkh!4m2!1x500113093!2x83511942!8b1!15sgcid%3Acompound_building!2b0!3b0!6b0!8b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=48498)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i16!2i34287!3i22222!4i256!2m3!1e0!2sm!3i798564590!2m3!1e2!2sspotlit!5i1!3m13!2sde!3sDE!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m16!299174093m15!14m14!1m9!1m2!1y5169455398793214567!2y1260128461620753167!2s%2Fg%2F11bw3x2gkh!4m2!1x500113093!2x83511942!8b1!15sgcid%3Acompound_building!2b0!3b0!6b0!8b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=49791)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i16!2i34288!3i22222!4i256!2m3!1e0!2sm!3i798564590!2m3!1e2!2sspotlit!5i1!3m13!2sde!3sDE!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m16!299174093m15!14m14!1m9!1m2!1y5169455398793214567!2y1260128461620753167!2s%2Fg%2F11bw3x2gkh!4m2!1x500113093!2x83511942!8b1!15sgcid%3Acompound_building!2b0!3b0!6b0!8b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=18490)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i16!2i34289!3i22222!4i256!2m3!1e0!2sm!3i798564698!2m3!1e2!2sspotlit!5i1!3m13!2sde!3sDE!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m16!299174093m15!14m14!1m9!1m2!1y5169455398793214567!2y1260128461620753167!2s%2Fg%2F11bw3x2gkh!4m2!1x500113093!2x83511942!8b1!15sgcid%3Acompound_building!2b0!3b0!6b0!8b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=104207)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i16!2i34289!3i22223!4i256!2m3!1e0!2sm!3i798564698!2m3!1e2!2sspotlit!5i1!3m13!2sde!3sDE!5e289!12m5!1e68!2m2!1sset!2sRoadmap!4e2!12m3!1e37!2m1!1ssmartmaps!4e0!5m1!1e3!23i47083502!27m16!299174093m15!14m14!1m9!1m2!1y5169455398793214567!2y1260128461620753167!2s%2Fg%2F11bw3x2gkh!4m2!1x500113093!2x83511942!8b1!15sgcid%3Acompound_building!2b0!3b0!6b0!8b0&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=102914)

![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2018%2018%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22M0%200v6h2V2h4V0zm16%200h-4v2h4v4h2V0zm0%2016h-4v2h6v-6h-2zM2%2012H0v6h6v-2H2z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2018%2018%22%3E%3Cpath%20fill%3D%22%23333%22%20d%3D%22M0%200v6h2V2h4V0zm16%200h-4v2h4v4h2V0zm0%2016h-4v2h6v-6h-2zM2%2012H0v6h6v-2H2z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2018%2018%22%3E%3Cpath%20fill%3D%22%23111%22%20d%3D%22M0%200v6h2V2h4V0zm16%200h-4v2h4v4h2V0zm0%2016h-4v2h6v-6h-2zM2%2012H0v6h6v-2H2z%22/%3E%3C/svg%3E)

![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2019.175%202.125-2.125%201.425%201.4L12%2022l-3.55-3.55%201.425-1.4zM4.825%2012l2.125%202.125-1.4%201.425L2%2012l3.55-3.55%201.4%201.425zm14.35%200L17.05%209.875l1.4-1.425L22%2012l-3.55%203.55-1.4-1.425zM12%204.825%209.875%206.95%208.45%205.55%2012%202l3.55%203.55-1.425%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2019.175%202.125-2.125%201.425%201.4L12%2022l-3.55-3.55%201.425-1.4zM4.825%2012l2.125%202.125-1.4%201.425L2%2012l3.55-3.55%201.4%201.425zm14.35%200L17.05%209.875l1.4-1.425L22%2012l-3.55%203.55-1.4-1.425zM12%204.825%209.875%206.95%208.45%205.55%2012%202l3.55%203.55-1.425%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%231a73e8%22%20d%3D%22m12%2019.175%202.125-2.125%201.425%201.4L12%2022l-3.55-3.55%201.425-1.4zM4.825%2012l2.125%202.125-1.4%201.425L2%2012l3.55-3.55%201.4%201.425zm14.35%200L17.05%209.875l1.4-1.425L22%2012l-3.55%203.55-1.4-1.425zM12%204.825%209.875%206.95%208.45%205.55%2012%202l3.55%203.55-1.425%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23d1d1d1%22%20d%3D%22m12%2019.175%202.125-2.125%201.425%201.4L12%2022l-3.55-3.55%201.425-1.4zM4.825%2012l2.125%202.125-1.4%201.425L2%2012l3.55-3.55%201.4%201.425zm14.35%200L17.05%209.875l1.4-1.425L22%2012l-3.55%203.55-1.4-1.425zM12%204.825%209.875%206.95%208.45%205.55%2012%202l3.55%203.55-1.425%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2010.8-4.6%204.6L6%2014l6-6%206%206-1.4%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23333%22%20d%3D%22m12%2010.8-4.6%204.6L6%2014l6-6%206%206-1.4%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2010.8-4.6%204.6L6%2014l6-6%206%206-1.4%201.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23d1d1d1%22%20d%3D%22m12%2010.8-4.6%204.6L6%2014l6-6%206%206-1.4%201.4z%22/%3E%3C/svg%3E)
![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m14%2018-6-6%206-6%201.4%201.4-4.6%204.6%204.6%204.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23333%22%20d%3D%22m14%2018-6-6%206-6%201.4%201.4-4.6%204.6%204.6%204.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m14%2018-6-6%206-6%201.4%201.4-4.6%204.6%204.6%204.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23d1d1d1%22%20d%3D%22m14%2018-6-6%206-6%201.4%201.4-4.6%204.6%204.6%204.6z%22/%3E%3C/svg%3E)
![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22M12.6%2012%208%207.4%209.4%206l6%206-6%206L8%2016.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23333%22%20d%3D%22M12.6%2012%208%207.4%209.4%206l6%206-6%206L8%2016.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22M12.6%2012%208%207.4%209.4%206l6%206-6%206L8%2016.6z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23d1d1d1%22%20d%3D%22M12.6%2012%208%207.4%209.4%206l6%206-6%206L8%2016.6z%22/%3E%3C/svg%3E)
![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2015.4-6-6L7.4%208l4.6%204.6L16.6%208%2018%209.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23333%22%20d%3D%22m12%2015.4-6-6L7.4%208l4.6%204.6L16.6%208%2018%209.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2015.4-6-6L7.4%208l4.6%204.6L16.6%208%2018%209.4z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23666%22%20d%3D%22m12%2015.4-6-6L7.4%208l4.6%204.6L16.6%208%2018%209.4z%22/%3E%3C/svg%3E)
![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23666%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M440-440H200v-80h240v-240h80v240h240v80H520v240h-80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23333%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M440-440H200v-80h240v-240h80v240h240v80H520v240h-80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23111%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M440-440H200v-80h240v-240h80v240h240v80H520v240h-80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23d1d1d1%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M440-440H200v-80h240v-240h80v240h240v80H520v240h-80z%22/%3E%3C/svg%3E)
![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23666%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M200-440v-80h560v80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23333%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M200-440v-80h560v80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23111%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M200-440v-80h560v80z%22/%3E%3C/svg%3E)![](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22%23d1d1d1%22%20viewBox%3D%220%20-960%20960%20960%22%3E%3Cpath%20d%3D%22M200-440v-80h560v80z%22/%3E%3C/svg%3E)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i13!2i4286!3i2777!4i256!2m1!1e1!3m12!2sde!3sDE!5e289!12m3!1e37!2m1!1ssmartmaps!12m4!1e26!2m2!1sstyles!2zcy5lOmx8cC52Om9mZg!4e0!5m1!1e3!23i47083502&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=5709)

![](https://www.google.com/maps/vt?pb=!1m5!1m4!1i13!2i4285!3i2777!4i256!2m1!1e1!3m12!2sde!3sDE!5e289!12m3!1e37!2m1!1ssmartmaps!12m4!1e26!2m2!1sstyles!2zcy5lOmx8cC52Om9mZg!4e0!5m1!1e3!23i47083502&key=AIzaSyCmL18misQw9KdwqGaw3zHkitj8vG6QF2Y&token=33227)

![Google](data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2069%2029%22%3E%3Cg%20fill%3D%22%23fff%22%20stroke%3D%22%23fff%22%20stroke-width%3D%221.5%22%20opacity%3D%22.6%22%3E%3Cpath%20d%3D%22m17.4706%207.33616.5412-.54112-.5519-.53011c-1.3636-1.30974-3.2017-2.31971-5.7591-2.31971-4.6137%200-8.50262%203.75517-8.50262%208.39578%200%204.6407%203.88892%208.3958%208.50262%208.3958%202.4704%200%204.3765-.8188%205.8732-2.3679%201.5695-1.5729%202.0216-3.7363%202.0216-5.4119%200-.5232-.044-1.0254-.1295-1.4529l-.1206-.6029h-8.3947v3.5942h4.8301c-.1724.5966-.4321%201.0286-.7491%201.3461-.6288.6214-1.5823%201.3094-3.331%201.3094-2.65245%200-4.73598-2.1312-4.73598-4.8099%200-2.67861%202.08353-4.80981%204.73598-4.80981%201.4362%200%202.4752.5607%203.257%201.29229l.5298.49574.513-.51303z%22/%3E%3Cpath%20d%3D%22M24.8656%2020.7286c3.089%200%205.6036-2.4192%205.6036-5.6692%200-3.2681-2.5162-5.66929-5.6036-5.66929-3.0873%200-5.6035%202.40119-5.6035%205.66929%200%203.25%202.5145%205.6692%205.6035%205.6692Zm0-7.9004c1.014%200%201.9766.837%201.9766%202.2312%200%201.3805-.9653%202.2311-1.9766%202.2311-1.0099%200-1.9765-.8574-1.9765-2.2311%200-1.3874.9639-2.2312%201.9765-2.2312Z%22/%3E%3Cpath%20d%3D%22M35.7511%2017.2905h-.0042c-1.0099%200-1.9766-.8574-1.9766-2.2311%200-1.3874.964-2.2312%201.9766-2.2312%201.0139%200%201.9765.837%201.9765%202.2312%200%201.3845-.968%202.2368-1.9723%202.2311Zm-.0124%203.4381c3.089%200%205.6035-2.4192%205.6035-5.6692%200-3.2681-2.5162-5.66929-5.6035-5.66929-3.0874%200-5.6036%202.40119-5.6036%205.66929%200%203.2508%202.5236%205.6692%205.6036%205.6692Z%22/%3E%3Cpath%20d%3D%22M51.953%2010.4357v-.74997h-3.5531v.12253c-.55-.26178-1.2022-.42639-1.9191-.42639-2.8837%200-5.464%202.51793-5.464%205.69393%200%202.1269%201.164%203.9479%202.8033%204.9137l-.0658.0273-1.8806.7802-.6929.2874.2876.6928c.6228%201.5004%202.2776%203.3697%205.0535%203.3697%201.4105%200%202.787-.4145%203.814-1.4093%201.0332-1.0009%201.6171-2.4965%201.6171-4.4653zm-7.2194%209.9844-.0002-.0005c.5552.2005%201.1446.309%201.7474.309.6808%200%201.3058-.1467%201.841-.3891-.0876.3891-.2417.671-.4252.8682-.2812.3022-.7202.5011-1.3747.5011-.91190000000001%200-1.5201-.6476-1.7883-1.2887Zm1.9361-7.5919c.9722%200%201.878.8483%201.878%202.2558%200%201.3796-.8956%202.2147-1.878%202.2147-1.0428%200-1.993-.8738-1.993-2.2147%200-1.3754.9595-2.2558%201.993-2.2558Zm9.069-7.60737v-.75h-3.6599V20.4412h3.6599z%22/%3E%3Cpath%20d%3D%22m63.9128%2016.0614-.6183-.4122-.4179.6145c-.4562.6709-1.0102%201.0432-1.8025%201.0432-.4306%200-.7595-.0981-1.0197-.2622-.07-.0441-.1383-.0951-.2046-.1536l5.6999-2.3625.6825-.283L65.9596%2013.5589l-.219-.5514c-.4528-1.2075-1.8899-3.60918-4.9128-3.60918-2.9833%200-5.3244%202.36358-5.3244%205.66928%200%203.1475%202.3222%205.6693%205.5625%205.6693%202.6043%200%204.1111-1.5991%204.7283-2.5156l.421-.625L65.5882%2017.1783zm-2.5667-3.2103-1.9353.8015c.3795-.5743%201.0107-.8572%201.4909-.8572.1653%200%20.3136.0207.4444.0557Z%22/%3E%3C/g%3E%3Cpath%20fill%3D%22%234285f4%22%20d%3D%22M11.7008%2019.9868c-4.21304%200-7.75262-3.4328-7.75262-7.6458%200-4.21297%203.53958-7.64578%207.75262-7.64578%202.3323%200%203.9912.91159%205.2395%202.11061l-1.47%201.47003c-.8952-.83767-2.1106-1.49467-3.7695-1.49467-3.07972%200-5.48598%202.48016-5.48598%205.55981%200%203.0797%202.40626%205.5599%205.48598%205.5599%201.9956%200%203.1289-.8048%203.8598-1.5275.5995-.5996.9855-1.4537%201.1333-2.628h-4.9931v-2.0942h7.0298c.0739.3695.115.8212.115%201.3058%200%201.5685-.427%203.5067-1.8067%204.8864-1.3469%201.3961-3.0551%202.1434-5.3381%202.1434%22/%3E%3Cpath%20fill%3D%22%23e94235%22%20d%3D%22M29.7192%2015.0594c0%202.8333-2.1763%204.9192-4.8536%204.9192-2.6772%200-4.8535-2.0859-4.8535-4.9192%200-2.8498%202.1763-4.9193%204.8535-4.9193%202.6773%200%204.8536%202.0695%204.8536%204.9193m-2.127%200c0-1.7739-1.2648-2.9812-2.7266-2.9812s-2.7265%201.2155-2.7265%202.9812c0%201.7492%201.2647%202.9811%202.7265%202.9811s2.7266-1.2237%202.7266-2.9811%22/%3E%3Cpath%20fill%3D%22%23fabb05%22%20d%3D%22M40.5922%2015.0594c0%202.8333-2.1763%204.9192-4.8535%204.9192-2.6691%200-4.8536-2.0859-4.8536-4.9192%200-2.8498%202.1763-4.9193%204.8536-4.9193%202.6772%200%204.8535%202.0695%204.8535%204.9193m-2.1188%200c0-1.7739-1.2647-2.9812-2.7265-2.9812s-2.7266%201.2155-2.7266%202.9812c0%201.7492%201.2648%202.9811%202.7266%202.9811%201.4618.0082%202.7265-1.2237%202.7265-2.9811%22/%3E%3Cpath%20fill%3D%22%234285f4%22%20d%3D%22M51.203%2010.4357v8.8366c0%203.6382-2.1435%205.1246-4.6811%205.1246-2.3899%200-3.8188-1.6014-4.3609-2.9072l1.8807-.7802c.3367.8048%201.158%201.7493%202.4802%201.7493%201.626%200%202.628-1.0101%202.628-2.8908v-.7063h-.074c-.4845.5995-1.4207%201.1169-2.5951%201.1169-2.4637%200-4.714-2.1434-4.714-4.9028%200-2.7758%202.2585-4.9439%204.714-4.9439%201.1744%200%202.1106.5256%202.5951%201.1004h.074v-.7966zm-1.9053%204.6483c0-1.7328-1.158-3.0058-2.628-3.0058-1.4947%200-2.743%201.2647-2.743%203.0058%200%201.7164%201.2483%202.9647%202.743%202.9647%201.47%200%202.628-1.2483%202.628-2.9647%22/%3E%3Cpath%20fill%3D%22%2334a853%22%20d%3D%22M54.9887%205.22083V19.6912h-2.1599V5.22083z%22/%3E%3Cpath%20fill%3D%22%23e94235%22%20d%3D%22m63.4968%2016.6854%201.6754%201.1169c-.5421.8049-1.8478%202.1846-4.1063%202.1846-2.8004%200-4.8125-2.1599-4.8125-4.9193%200-2.9237%202.0367-4.9193%204.5744-4.9193%202.554%200%203.8023%202.0285%204.213%203.129l.2217.5584-6.5782%202.7266c.501.9855%201.2894%201.4946%202.3898%201.4946%201.1005%200%201.8643-.5502%202.4227-1.3715m-5.1656-1.7739%204.4019-1.8231c-.2464-.616-.9691-1.043-1.8314-1.043-1.1005%200-2.628.9691-2.5705%202.8661%22/%3E%3C/svg%3E)

Kurzbefehle

KartendatenKartendaten ©2026 GeoBasis-DE/BKG (©2009), Google

Kartendaten ©2026 GeoBasis-DE/BKG (©2009), Google

100 m

Klicken, um zwischen metrischen und angloamerikanischen Maßeinheiten zu wechseln

[Nutzungsbedingungen](https://www.google.com/intl/de_DE/help/terms_maps.html)

[Fehler bei Google Maps melden](https://www.google.com/maps/@50.0113093,8.3511942,16z/data=!10m1!1e1!12b1?source=apiv3&rapsrc=apiv3 "Google falsche Straßenkarte oder Bilder melden")

ADAC Schlüsselnotdienst-Partner in Ihrer Stadt

![schließen](https://www.ratedo.de/res/close2.svg)

[![ratedo Bewertungssiegel Smart](https://www.ratedo.de/badges/ratedo-bewertungssiegel-smart.svg)\\
\\
239 Bewertungen für Schlüsseldienst Adam verfügbar \\
\\
Bewertungen ansehen](https://www.ratedo.de/profil/schluesseldienst-adam)

[![ratedo Logo](https://www.ratedo.de/res/ratedo-logo.svg)\\
\| \\
\\
239 Bewertungen verfügbar \\
\| \\
\\
Bewertungen ansehen](https://www.ratedo.de/profil/schluesseldienst-adam)